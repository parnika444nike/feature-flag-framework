package com.bmt.webapp.models;

import jakarta.validation.constraints.*;

public class ClientDto {
	@NotEmpty(message="Please add a name")
	private String ffname;
	
	private String creator="Raghu";
	
	@NotEmpty(message="Please set the status")
	private String status;
	
	
	@NotEmpty(message="Please add a start date")
	private String createdat;
	
	@NotEmpty(message="Please add a end date")
	private String enddate;
	

	
	private String starttime;
	private String endtime;
	
	
	
	

	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	private String description;
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getCreatedat() {
		return createdat;
	}
	public void setCreatedat(String createdat) {
		this.createdat = createdat;
	}
	
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	
	public String getFfname() {
		return ffname;
	}
	public void setFfname(String ffname) {
		this.ffname = ffname;
	}
	
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}