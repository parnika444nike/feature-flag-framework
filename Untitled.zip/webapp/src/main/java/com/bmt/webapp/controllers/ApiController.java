package com.bmt.webapp.controllers;

import com.bmt.webapp.models.*;
import com.bmt.webapp.repositories.*;
import org.spring.framework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ApiController{
	
	
	private final ClientRepository clientRepository;
	

	public ApiController(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}
	
	@GetMapping ("/feature-flags")
	public List<Client> getAllClients(){
		return clientRepository.findAll();
	}
	
}