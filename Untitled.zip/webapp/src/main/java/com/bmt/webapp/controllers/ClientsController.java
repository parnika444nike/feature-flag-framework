package com.bmt.webapp.controllers;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.bmt.webapp.models.Client;
import com.bmt.webapp.models.ClientDto;
import com.bmt.webapp.repositories.ClientRepository;

import jakarta.validation.Valid;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

@Controller
@RequestMapping("/clients")
public class ClientsController {

	@Autowired
	private ClientRepository clientRepo;
	
	@GetMapping({"","/"})
	public String getClients(Model model) {
		var clients=clientRepo.findAll(Sort.by(Sort.Direction.ASC, "id"));
		model.addAttribute("clients", clients);
		return "clients/index";
	}
	
	@GetMapping("/create")
	public String createClient(Model model) {
		ClientDto clientDto = new ClientDto();
		model.addAttribute("clientDto", clientDto);
		
		return "clients/create";
	}
	
	
	@PostMapping("/create")
	public String createClient(
			@Valid @ModelAttribute ClientDto clientDto,
			BindingResult result) {
		if(clientRepo.findByFfname(clientDto.getFfname())!=null) {
			new FieldError("clientDto", "Ffname", clientDto.getFfname(),
					false, null, null, "Invalid ID");
	} 
		
	if(result.hasErrors()) {
		return "clients/create";
	}
	
			
	Client client=new Client();
	
	client.setFfname(clientDto.getFfname());
	client.setStatus(clientDto.getStatus());
	client.setCreatedat(clientDto.getCreatedat());
	client.setEnddate(clientDto.getEnddate());
	client.setDescription(clientDto.getDescription());
	
	
	
	
	clientRepo.save(client);
	return "redirect:/clients";
	
	}
	
	
	
	@GetMapping("/edit")public String editClient(Model model, @RequestParam int id) {
		Client client = clientRepo.findByid(id);
		if (client==null) {
			return "redirect:clients";
		}
		
		Client clientDto = new Client();
		clientDto.setFfname(client.getFfname());
		clientDto.setCreator(client.getCreator());
		clientDto.setStatus(client.getStatus());
		clientDto.setDescription(client.getDescription());
		
		
		model.addAttribute("client", client);
		model.addAttribute("clientDto", clientDto);
		
		return "clients/edit";
	}
	
	
	@PostMapping("/edit")
	public String editClient(
			Model model,
			@RequestParam int id, 
			@Valid @ModelAttribute ClientDto clientDto,
			BindingResult result)
	{
		
		Client client = clientRepo.findByid(id);
		if(client==null) {
			return "redirect:/clients";
		}
		model.addAttribute("client", client);
		
		if(result.hasErrors()) {
			return "clients/edit";
		}
		
		client.setFfname(clientDto.getFfname());
		client.setCreator(clientDto.getCreator());
		client.setStatus(clientDto.getStatus());
		client.setDescription(clientDto.getDescription());
		
		
		try {
			clientRepo.save(client);
		}
		catch(Exception ex) {
			result.addError(new FieldError("clientDto", "ffname", clientDto.getFfname(),
						false, null, null, "Name already in use"));
		;
		return "clients/edit";
		
	}
		
		return "redirect:/clients";
	}
	
	
	@GetMapping("/view")public String viewClient(Model model, @RequestParam int id) {
		Client client = clientRepo.findByid(id);
		if (client==null) {
			return "redirect:clients";
		}
		
		Client clientDto = new Client();
		clientDto.setFfname(client.getFfname());
		clientDto.setCreator(client.getCreator());
		clientDto.setStatus(client.getStatus());
		clientDto.setDescription(client.getDescription());
		clientDto.setEnddate(client.getEnddate());
		
		clientDto.setCreatedat(client.getCreatedat());
		
		
		
		model.addAttribute("client", client);
		model.addAttribute("clientDto", clientDto);
		
		return "clients/view";
	}
	
	@PostMapping("/view")
	public String viewClient(
			Model model,
			@RequestParam int id, 
			@Valid @ModelAttribute ClientDto clientDto,
			BindingResult result)
	{
		
		Client client = clientRepo.findByid(id);
		if(client==null) {
			return "redirect:/clients";
		}
		model.addAttribute("client", client);
		
		if(result.hasErrors()) {  
			return "clients/view";
		}
		
		client.setFfname(clientDto.getFfname());
		client.setCreator(clientDto.getCreator());
		client.setStatus(clientDto.getStatus());
		client.setDescription(clientDto.getDescription());
		clientDto.setEnddate(client.getEnddate());
		
		clientDto.setCreatedat(client.getCreatedat());
		
		
		
		try {
			clientRepo.save(client);
		}
		catch(Exception ex) {
			result.addError(new FieldError("clientDto", "ffname", clientDto.getFfname(),
						false, null, null, "Name already in use"));
		;
		return "clients/view";
		
	}
		
		return "redirect:/clients";
	}
	
	
	
	
	
	
}
