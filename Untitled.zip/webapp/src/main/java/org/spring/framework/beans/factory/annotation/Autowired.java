package org.spring.framework.beans.factory.annotation;

public class Autowired {

}
